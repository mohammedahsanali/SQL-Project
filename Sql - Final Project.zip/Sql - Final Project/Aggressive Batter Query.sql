--player who faced more than 500 balls Excluding wides.
SELECT batsman as Player_Name, 
SUM(CASE WHEN extras_type != 'wides' THEN batsman_runs ELSE 0 END) AS RunsScored,
COUNT(ball) AS Balls_faced 
FROM ipl_ball
WHERE extras_type != 'wides'
GROUP BY batsman 
HAVING COUNT(ball) >= 500
ORDER BY balls_faced DESC 
LIMIT 10

--player who have high strike rate of top 10 Excluding wides.
SELECT batsman AS PlayerName, 
(SUM(CASE WHEN extras_type != 'wides' THEN batsman_runs ELSE 0 END) * 100.0 / NULLIF(COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE 0 END), 0)) AS StrikeRate
FROM ipl_ball 
WHERE extras_type != 'wides'
GROUP BY batsman
ORDER BY StrikeRate DESC 
LIMIT 10;

--player who faced morethan 500 balls and have high strike rate Excluding wides.
SELECT batsman AS PlayerName,
    SUM(CASE WHEN extras_type != 'wides' THEN batsman_runs ELSE 0 END) AS RunsScored,
    COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE 0 END) AS BallsFaced,
    (SUM(CASE WHEN extras_type != 'wides' THEN batsman_runs ELSE 0 END) * 100.0 / NULLIF(COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE 0 END), 0)) AS StrikeRate
FROM ipl_ball 
WHERE extras_type != 'wides'
GROUP BY batsman
HAVING COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE 0 END) >= 500
ORDER BY StrikeRate DESC 
LIMIT 10;