--player who have played more than 2 ipl seasons
SELECT b.batsman AS player_name, 
COUNT(DISTINCT EXTRACT(YEAR FROM m.date)) AS num_seasons_played
FROM ipl_ball AS b 
JOIN ipl_matches AS m 
ON b.id = m.id
GROUP BY b.batsman 
HAVING COUNT(DISTINCT EXTRACT(YEAR FROM m.date)) > 2
ORDER BY num_seasons_played DESC 
LIMIT 10;

--player who have played 4 and 6 and most runs in boudaries
SELECT batsman AS player_name,
SUM(CASE WHEN batsman_runs = 4 THEN 1 ELSE 0 END) AS fours, SUM(CASE WHEN batsman_runs = 6 THEN 1 ELSE 0 END) AS sixes,
SUM(CASE WHEN batsman_runs IN (4, 6) THEN 1 ELSE 0 END) AS total_boundaries,
SUM(CASE WHEN batsman_runs IN (4, 6) THEN batsman_runs ELSE 0 END) AS boundary_runs,
ROUND(SUM(CASE WHEN batsman_runs IN (4, 6) THEN batsman_runs ELSE 0 END) * 100.0 / SUM(total_runs), 2) AS boundary_percentage
FROM ipl_ball as b 
WHERE batsman_runs IN (4, 6)
GROUP BY batsman 
ORDER BY boundary_runs DESC 
LIMIT 10;

--player who have played 4 and 6 and most runs in boudaries with played more than 2 ipl seasons
SELECT b.batsman AS player_name,
SUM(CASE WHEN b.batsman_runs IN (4, 6) THEN b.batsman_runs ELSE 0 END) AS boundary_runs,
ROUND(SUM(CASE WHEN b.batsman_runs IN (4, 6) THEN b.batsman_runs ELSE 0 END) * 100.0 / SUM(b.total_runs), 2) AS boundary_percentage,
COUNT(DISTINCT EXTRACT(YEAR FROM m.date)) AS num_seasons_played
FROM ipl_ball AS b 
JOIN ipl_matches AS m 
ON b.id = m.id
WHERE b.batsman_runs IN (4, 6)
GROUP BY b.batsman 
HAVING COUNT(DISTINCT EXTRACT(YEAR FROM m.date)) > 2
ORDER BY boundary_runs DESC 
LIMIT 10;