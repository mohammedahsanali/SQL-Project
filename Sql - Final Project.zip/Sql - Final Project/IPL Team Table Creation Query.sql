--Ipl_ball table creation query.
CREATE TABLE IPL_BALL (ID int, INNING int, OVER int, BALL int, BATSMAN varchar, NON_STRIKER varchar, BOWLER varchar, BATSMAN_RUNS int, EXTRA_RUNS int, TOTAL_RUNS int, IS_WICKET int, DISMISSAL_KIND varchar, PLAYER_DISMISSED varchar, FIELDER varchar, EXTRAS_TYPE varchar, BATTING_TEAM varchar, BOWLING_TEAM varchar);
--Importing CSV file.
COPY IPL_BALL
FROM 'C:\Program Files\PostgreSQL\15\data\A - SQL - Data Sources\M1_T4_V1 Restore\IPL Dataset\IPL_Ball.csv'
DELIMITER ',' CSV HEADER;

--Ipl_matches table creation query.
CREATE TABLE IPL_MATCHES (ID int, CITY varchar, date date, PLAYER_OF_MATCH varchar, VENUE varchar, NEUTRAL_VENUE int, TEAM1 varchar, TEAM2 varchar, TOSS_WINNER varchar, TOSS_DECISION varchar, WINNER varchar, RESULT varchar, RESULT_MARGIN int, ELIMINATOR varchar, METHOD varchar, UMPIRE1 varchar, UMPIRE2 varchar);
--Importing CSV file.
COPY IPL_MATCHES
FROM 'C:\Program Files\PostgreSQL\15\data\A - SQL - Data Sources\M1_T4_V1 Restore\IPL Dataset\IPL_matches.csv'
DELIMITER ',' CSV HEADER;