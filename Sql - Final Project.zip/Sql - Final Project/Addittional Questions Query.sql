--Q1
SELECT COUNT(DISTINCT city) AS total_cities
FROM matches;
--Q2
CREATE TABLE deliveries_v02 AS
SELECT *,
       CASE
           WHEN total_runs >= 4 THEN 'boundary'
           WHEN total_runs = 0 THEN 'dot'
           ELSE 'other'
       END AS ball_result
FROM deliveries;
--Q3
SELECT 
    ball_result,
    COUNT(*) AS count
FROM deliveries_v02
WHERE ball_result IN ('boundary', 'dot')
GROUP BY ball_result;
--Q4
SELECT 
    batting_team,
    SUM(CASE WHEN ball_result = 'boundary' THEN 1 ELSE 0 END) AS total_boundaries
FROM deliveries_v02
GROUP BY batting_team
ORDER BY total_boundaries DESC;
--Q5
SELECT 
    bowling_team,
    SUM(CASE WHEN ball_result = 'dot' THEN 1 ELSE 0 END) AS total_dot_balls
FROM deliveries_v02
GROUP BY bowling_team
ORDER BY total_dot_balls DESC;
--Q6
SELECT 
    dismissal_kind,
    COUNT(*) AS total_dismissals
FROM deliveries_v02
WHERE dismissal_kind != 'NA'
GROUP BY dismissal_kind;
--Q7
SELECT 
    bowler,
    SUM(extra_runs) AS total_extra_runs
FROM deliveries_v02
GROUP BY bowler
ORDER BY total_extra_runs DESC
LIMIT 5;
--Q8
CREATE TABLE deliveries_v03 AS
	SELECT d.*, m.venue, m.date
	FROM deliveries_v02 AS d
	JOIN matches AS m ON d.id = m.id;
--Q9
SELECT 
    venue,
    SUM(total_runs) AS total_runs_scored
FROM deliveries_v03
GROUP BY venue
ORDER BY total_runs_scored DESC;
--Q10
SELECT 
    EXTRACT(YEAR FROM date) AS year,
    SUM(total_runs) AS total_runs_scored
FROM deliveries_v03
WHERE venue = 'Eden Gardens'
GROUP BY EXTRACT(YEAR FROM date)
ORDER BY total_runs_scored DESC;