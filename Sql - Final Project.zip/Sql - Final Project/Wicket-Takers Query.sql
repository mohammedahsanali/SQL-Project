--players who bowled more than 500 balls
SELECT bowler AS player_name, 
COUNT(ball) AS balls_bowled
FROM ipl_ball
GROUP BY player_name 
HAVING COUNT(*) > 0 AND COUNT(ball) >= 500
ORDER BY balls_bowled DESC LIMIT 10;

--players who have high strike rate
SELECT bowler AS player_name,
SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END) AS total_wickets_taken
FROM ipl_ball
GROUP BY bowler
HAVING COUNT(*) > 0 AND SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END) > 0
ORDER BY total_wickets_taken DESC 
LIMIT 10;

--players who have high strike rate and who bowled more than 500 balls
SELECT bowler AS player_name,
COUNT(ball) AS TotalBallsBowled,
SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END) AS TotalWicketsTaken,
(COUNT(ball) * 1.0 / NULLIF(SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END), 0)) AS StrikeRate
FROM ipl_ball
GROUP BY bowler
HAVING COUNT(*) > 0 AND COUNT(ball) >= 500 AND SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END) > 0
ORDER BY StrikeRate DESC 
LIMIT 10;