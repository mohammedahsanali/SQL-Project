--player who have played more than 2 ipl seasons
SELECT b.batsman AS player_name, 
COUNT(DISTINCT EXTRACT(YEAR FROM m.date)) AS num_seasons_played
FROM ipl_ball AS b 
JOIN ipl_matches AS m 
ON b.id = m.id
GROUP BY b.batsman 
HAVING COUNT(DISTINCT EXTRACT(YEAR FROM m.date)) > 2
ORDER BY num_seasons_played DESC 
LIMIT 10;

--player who have good average with dismissals
SELECT b.batsman AS player_name,
SUM(b.is_wicket) AS Dismissals, 
(SUM(b.batsman_runs) / NULLIF(SUM(b.is_wicket), 0)) AS Batting_Average
FROM IPL_BALL 
JOIN IPL_MATCHES as m 
ON b.id = m.id
GROUP BY b.batsman 
HAVING SUM(b.is_wicket) > 0
ORDER BY Batting_Average DESC 
LIMIT 10;

--players who played more than 2 seasons and having good averages with dismissals.
SELECT b.batsman AS player_name, 
COUNT(DISTINCT EXTRACT(YEAR FROM m.date)) AS seasons_played,
SUM(b.is_wicket) AS Dismissals, 
(SUM(b.batsman_runs) / NULLIF(SUM(b.is_wicket), 0)) AS batting_average
FROM ipl_ball as b 
JOIN ipl_matches as m 
ON b.id = m.id
GROUP BY b.batsman 
HAVING COUNT(DISTINCT EXTRACT(YEAR FROM m.date)) > 2 AND SUM(b.is_wicket) > 0
ORDER BY batting_average DESC 
LIMIT 10;