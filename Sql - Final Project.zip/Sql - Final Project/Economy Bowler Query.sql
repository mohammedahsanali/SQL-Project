--players who bowled more than 500 balls
SELECT bowler AS player_name,
COUNT(ball) AS balls_bowled FROM ipl_ball
GROUP BY bowler 
HAVING COUNT(ball) >= 500 
ORDER BY balls_bowled DESC
LIMIT 10

--players who have good economy
SELECT bowler, 
SUM(total_runs) AS total_runs_conceded,
COUNT(DISTINCT CONCAT(over, '.', ball)) AS total_overs_bowled,
ROUND(SUM(total_runs) / COUNT(DISTINCT CONCAT(over, '.', ball)), 2) AS economy_rate
FROM ipl_ball 
GROUP BY bowler 
HAVING COUNT(DISTINCT CONCAT(over, '.', ball)) > 0
ORDER BY economy_rate DESC 
LIMIT 10;

--players who have bowled morethan 500 bolls and have good average
SELECT bowler AS player_name,
SUM(total_runs) AS total_runs_conceded,
COUNT(DISTINCT CONCAT(over, '.', ball)) AS total_overs_bowled,
ROUND(SUM(total_runs) / COUNT(DISTINCT CONCAT(over, '.', ball)), 2) AS economy_rate
FROM ipl_ball 
GROUP BY bowler 
HAVING COUNT(ball) >= 500 AND COUNT(DISTINCT CONCAT(over, '.', ball)) > 0
ORDER BY economy_rate DESC 
LIMIT 10;