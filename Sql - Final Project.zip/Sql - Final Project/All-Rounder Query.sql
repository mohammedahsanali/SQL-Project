--player who faced morethan 500 balls and have high strike rate As Batter's.
SELECT batsman AS PlayerName,
SUM(CASE WHEN extras_type != 'wides' THEN batsman_runs ELSE 0 END) AS RunsScored,
COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE 0 END) AS BallsFaced,
(SUM(CASE WHEN extras_type != 'wides' THEN batsman_runs ELSE 0 END) * 100.0 / NULLIF(COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE 0 END), 0)) AS StrikeRate
FROM ipl_ball 
WHERE extras_type != 'wides'
GROUP BY batsman
HAVING COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE 0 END) >= 500
ORDER BY StrikeRate DESC 
LIMIT 10;

--players who have high strike rate and who bowled more than 300 balls
SELECT bowler AS PlayerName,
COUNT(ball) AS TotalBallsBowled,
SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END) AS TotalWicketsTaken,
(COUNT(ball) * 1.0 / NULLIF(SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END), 0)) AS StrikeRate
FROM ipl_ball
GROUP BY bowler
HAVING COUNT(*) > 0 AND COUNT(ball) >= 300 AND SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END) > 0
ORDER BY StrikeRate DESC 
LIMIT 10;

--player who faced morethan 500 and 300 balls and have high strike rate.
SELECT batsman AS PlayerName,
COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE NULL END) AS BallsFaced,
(SUM(batsman_runs) * 100.0 / NULLIF(COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE NULL END), 0)) AS Batter_StrikeRate,
SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END) AS total_wickets_taken,
(COUNT(ball) * 1.0 / NULLIF(SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END), 0)) AS Bowler_StrikeRate
FROM ipl_ball
WHERE extras_type != 'wides'
GROUP BY batsman
HAVING COUNT(CASE WHEN extras_type != 'wides' THEN 1 ELSE NULL END) >= 500 AND SUM(CASE WHEN is_wicket = 1 THEN 1 ELSE 0 END) > 0 AND COUNT(ball) >= 300
ORDER BY Batter_StrikeRate DESC, Bowler_StrikeRate DESC
LIMIT 10;